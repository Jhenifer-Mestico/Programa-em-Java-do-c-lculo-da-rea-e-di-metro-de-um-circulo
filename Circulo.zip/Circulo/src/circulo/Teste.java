package circulo;

public class Teste {
     
    public static void main(String[] args) {

       Circulo ObjCirculo = new Circulo();
       ObjCirculo.setRaio(4);
       System.out.println(ObjCirculo.getDados());  //NÃO esquecer de por o Obj antes
        
}
    }