package circulo;

public class Circulo {

    private double raio;

    public Circulo() {
        raio = 0;
    }
    
    public double getRaio(){
        return raio;
    }
    
    public double setRaio(double raio){
        if(raio < 0){
            this.raio = 0;
            return raio;
        }
        
        this.raio = raio;
        return raio;
    }
    
    public double CalculoArea(){
        return 3.14 * (raio * raio);
        
    }
    
    public double CalculoDiametro(){
        return raio * 2;
    }
    
    public String getDados(){
       
        return "A área será: " + CalculoArea() + "\nO diâmetro será: " + CalculoDiametro();
    
 } 
    }